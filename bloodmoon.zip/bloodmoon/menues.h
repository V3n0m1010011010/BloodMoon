Menu* activem;
Menu* mainm;

Menu* wifim;
Menu* wifiScanm;
Menu* wifiAttackm;
Menu* wifiSnifferm;
Menu* wifiGerneralm;

Menu* bluem;
Menu* blueScanm;
Menu* blueAttackm;
Menu* blueSnifferm;


Menu* settm;
Menu* settColorm;
Menu* settIconsm;